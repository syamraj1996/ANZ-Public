package com.anz.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.anz.entity.AccountListEntity;
import com.anz.repository.AccountListRepository;
/**
 * Junit for AccountListService
 * Created using Junit 4
 * @author syamraj
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class AccountListServiceTest {
	
	@Mock
	AccountListRepository accountListRepository;
	
	@InjectMocks
	AccountListService accountListService;

	@Test
	public void getAccountDetailsTest() {
		List<AccountListEntity> accountList = new ArrayList<>();
		AccountListEntity accountListEntity = prepareAccountListEntity(12545584l,"SGSavings456","savings","SGD",4578.50F);
		AccountListEntity accountListEntityTwo = prepareAccountListEntity(25497512l,"AUSavings456","savings","AU",24578.50F);
		accountList.add(accountListEntity);
		accountList.add(accountListEntityTwo);
		when(accountListRepository.findAll()).thenReturn(accountList);
		List <AccountListEntity> accountListEntities = accountListService.getAccountDetails();
		assertEquals(accountList, accountListEntities);
		
	}
	
	public AccountListEntity prepareAccountListEntity(Long accountNo, String accountName,
			String accountType, String currency, Float openingBalance) {
		AccountListEntity accountEntity = new AccountListEntity();
		accountEntity.setAccountNumber(accountNo);
		accountEntity.setAccountName(accountName);
		accountEntity.setAccountType(accountType);
		accountEntity.setBalanceDate(LocalDate.now());
		accountEntity.setCurrency(currency);
		accountEntity.setOpeningAvailableBalance(openingBalance);
		return accountEntity;
	}
}
