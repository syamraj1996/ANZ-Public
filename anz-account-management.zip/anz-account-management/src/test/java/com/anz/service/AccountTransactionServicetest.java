package com.anz.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.anz.entity.AccountListEntity;
import com.anz.entity.AccountTransactionEntity;
import com.anz.repository.AccountTransactionRepository;

/**
 * Junit test for Account Transaction Service
 * Using Junit 4
 * @author syamraj
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class AccountTransactionServicetest {
	
	@Mock
	AccountTransactionRepository accountTransactionRepository;
	
	@InjectMocks
	AccountTransactionService accountTransactionService;
	
	@Test
	public void getAccountTransactionDetailsTest() {
		
		List<AccountTransactionEntity> accountTransactionList = new ArrayList<AccountTransactionEntity>();
		AccountListEntity accountListEntity = prepareAccountListEntity(12545584l);
		
		AccountTransactionEntity accountTransactionEntity = prepareAccountTransactionEntity(1l,accountListEntity,
				"SGSavings456","SGD",2541.36F,0.0F,"Debit","Test");
		AccountTransactionEntity accountTransactionEntityTwo = prepareAccountTransactionEntity(1l,accountListEntity,
				"SGSavings456","SDG",2458.36F,0.0F,"Debit","Test");
		accountTransactionList.add(accountTransactionEntity);
		accountTransactionList.add(accountTransactionEntityTwo);
		when(accountTransactionRepository.getAccountTransactionByAccountId(accountListEntity)).thenReturn(accountTransactionList);
		
		List<AccountTransactionEntity> accTransactionEntity = accountTransactionService.getAccountTransactionDetails(12545584l);
		assertEquals(accountTransactionList, accTransactionEntity);
		
	}
	
	public AccountTransactionEntity prepareAccountTransactionEntity(Long transactionId, AccountListEntity 
			accountEntity, String accountName,String currency, Float debitAmount, Float creditAmount,
			String transactionType, String transactionNarrative) {
		AccountTransactionEntity accountTranasctionEntity = new AccountTransactionEntity();
		
		accountTranasctionEntity.setTransactionId(transactionId);
		accountTranasctionEntity.setAccountNumber(accountEntity);
		accountTranasctionEntity.setAccountName(accountName);
		accountTranasctionEntity.setCurrency(currency);
		accountTranasctionEntity.setCreditAmount(creditAmount);
		accountTranasctionEntity.setDebitAmount(debitAmount);
		accountTranasctionEntity.setTransactionType(transactionType);
		accountTranasctionEntity.setTransactionNarrative(transactionNarrative);
		accountTranasctionEntity.setValueDate(LocalDate.now());
		return accountTranasctionEntity;
	}
	public AccountListEntity prepareAccountListEntity(Long accountNo) {
		AccountListEntity accountEntity = new AccountListEntity();
		accountEntity.setAccountNumber(accountNo);
		return accountEntity;
	}

}
