package com.anz.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.anz.entity.AccountListEntity;

/**
 * repository class for Account list
 * @author syamraj
 *
 */
@Repository
public interface AccountListRepository extends JpaRepository<AccountListEntity, Long> {

}
