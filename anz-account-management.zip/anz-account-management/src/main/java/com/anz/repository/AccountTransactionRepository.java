package com.anz.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.anz.entity.AccountListEntity;
import com.anz.entity.AccountTransactionEntity;

/**
 * Repository class for Account transaction
 * @author syamraj
 *
 */
@Repository
public interface AccountTransactionRepository extends JpaRepository<AccountTransactionEntity, Long> {
	/*
	 * Query to fetch data using account id
	 */
	@Query("FROM AccountTransactionEntity WHERE accountNumber =:accountId")
	List<AccountTransactionEntity> getAccountTransactionByAccountId(AccountListEntity accountId);

}
