package com.anz.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.anz.entity.AccountListEntity;
import com.anz.entity.AccountTransactionEntity;
import com.anz.service.AccountListService;
import com.anz.service.AccountTransactionService;

import lombok.extern.slf4j.Slf4j;
/**
 * Rest controller for Account Management
 * Having two request mapping
 * @author syamraj
 *
 */
@Slf4j
@RestController
@RequestMapping("/account")
public class AccountController {

	@Autowired
	AccountListService accountListService;

	@Autowired
	AccountTransactionService accountTransactionService;

	/**
	 * For getting all the account details
	 * @return
	 */
	@PostMapping("/accountList")
	public ResponseEntity<?> getAccountList() {
		log.info("[START] getAccountList");
		try {
			List<AccountListEntity>accountListEntity = accountListService.getAccountDetails();

			log.info("[END] getAccountList");
			return new ResponseEntity<>(accountListEntity,HttpStatus.OK);
		}catch (Exception e) {
			return new ResponseEntity<>("Exception occurred ",HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	/**
	 *For getting the transaction details of a particular account 
	 * @param accountNumber
	 * @return
	 */
	@PostMapping("/accountTransaction")
	public ResponseEntity<?> getAccountTransaction(@RequestParam Long accountNumber) {
		log.info("[START] getAccountTransaction");
		try {
			List<AccountTransactionEntity>accountTransactionEntity = accountTransactionService.getAccountTransactionDetails(accountNumber);
			log.info("[END] getAccountTransaction");
			return new ResponseEntity<>(accountTransactionEntity,HttpStatus.OK);
		}catch (Exception e) {
			return new ResponseEntity<>("exception occurred ",HttpStatus.INTERNAL_SERVER_ERROR);
		}


	}

}
