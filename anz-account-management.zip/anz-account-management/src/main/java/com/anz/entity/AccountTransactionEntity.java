package com.anz.entity;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.ToString;

@Data
@Entity
@Table(name = "ACCOUNT_TRANSACTION")
@ToString
public class AccountTransactionEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="TRANSACTION_ID")
	private Long transactionId;//added this extra field to create a primary key

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "ACCOUNT_NUMBER", referencedColumnName = "ACCOUNT_NUMBER")
	private AccountListEntity accountNumber;

	@Column(name="ACCOUNT_NAME")
	private String accountName;

	@Column(name="VALUE_DATE")
	private LocalDate valueDate;

	@Column(name="CURRENCY")
	private String currency;

	@Column(name="DEBIT_AMOUNT")
	private Float debitAmount;

	@Column(name="CREDIT_AMOUNT")
	private Float creditAmount;

	@Column(name="DEBIT_OR_CREDIT")
	private String transactionType;

	@Column(name="TRANSACTION_NARRATIVE")
	String transactionNarrative;

}
