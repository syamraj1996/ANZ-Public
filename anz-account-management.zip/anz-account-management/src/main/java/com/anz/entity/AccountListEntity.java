package com.anz.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.ToString;

@Data
@Entity
@Table(name = "ACCOUNT_LIST")
@ToString
public class AccountListEntity {

	@Id
	@Column(name = "ACCOUNT_NUMBER")
	private Long accountNumber;

	@Column(name="ACCOUNT_NAME")
	private String accountName;

	@Column(name="ACCOUNT_TYPE")
	private String accountType;

	@Column(name="BALANCE_DATE")
	private LocalDate balanceDate;

	@Column(name="CURRENCY")
	String currency;

	@Column(name="OPENING_AVAILABLE_BALANCE")
	private Float openingAvailableBalance;


}
