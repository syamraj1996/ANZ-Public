package com.anz.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.anz.entity.AccountListEntity;
import com.anz.repository.AccountListRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * Service class for account operation
 * @author syamraj
 *
 */
@Slf4j
@Service
public class AccountListService {

	private AccountListRepository accountListRepository;


	public AccountListService(AccountListRepository accountListRepository) {
		this.accountListRepository = accountListRepository;
	}

	public List<AccountListEntity> getAccountDetails() {
		log.info("[Start] getAccountDetails");
		List<AccountListEntity> accountListEntity = new ArrayList<>();
		try {
			accountListEntity = accountListRepository.findAll();
		}catch (Exception e) {
			log.error("Error occured while fetching data.");
		}

		log.info("[END] getAccountDetails");
		return accountListEntity;
	}



}
