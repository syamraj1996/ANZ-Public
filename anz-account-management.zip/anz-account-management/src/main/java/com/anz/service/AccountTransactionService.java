package com.anz.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.anz.entity.AccountListEntity;
import com.anz.entity.AccountTransactionEntity;
import com.anz.repository.AccountTransactionRepository;

import lombok.extern.slf4j.Slf4j;
/**
 * Service class for account transaction operation
 * @author syamraj
 *
 */
@Slf4j
@Service
public class AccountTransactionService {

	private AccountTransactionRepository accountTransactionRepository;

	public AccountTransactionService(AccountTransactionRepository accountTransactionRepository) {
		this.accountTransactionRepository = accountTransactionRepository;
	}

	public List<AccountTransactionEntity> getAccountTransactionDetails(Long accountId) {
		log.info("[Start] getAccountTransactionDetails");
		AccountListEntity accountListEntity = new AccountListEntity();
		accountListEntity.setAccountNumber(accountId);
		List<AccountTransactionEntity> accountTransactionEntity = new ArrayList<AccountTransactionEntity>();
		try {
			accountTransactionEntity = accountTransactionRepository.getAccountTransactionByAccountId(accountListEntity);
		}catch (Exception e) {
			log.error("Error occured while fetching the transaction data");
		}
		log.info("[END] getAccountTransactionDetails");
		return accountTransactionEntity;
	}


}
